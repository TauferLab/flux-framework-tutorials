# /* Copyright (C) 2001
#  * Housemarque Oy
#  * http://www.housemarque.com
#  *
#  * Distributed under the Boost Software License, Version 1.0. (See
#  * accompanying file LICENSE_1_0.txt or copy at
#  * http://www.boost.org/LICENSE_1_0.txt)
#  */
#
# /* Revised by Paul Mensonides (2002) */
#
# /* See http://www.boost.org for most recent version. */
#
#ifndef __yas__detail__preprocessor__comma_hpp
#define __yas__detail__preprocessor__comma_hpp
#
# /* YAS_PP_COMMA */
#
# define YAS_PP_COMMA() ,
#
#endif // __yas__detail__preprocessor__comma_hpp
